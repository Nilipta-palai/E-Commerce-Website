// import React from "react";
// import { useNavigate, Link } from "react-router-dom";

// const products = [
//   {
//     id: 1,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Phalada Pure & Sure | Organic Coconut ",
//     category: "EXTRA VIRGIN OLIVE OILS",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 2,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 3,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 4,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 5,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 6,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 7,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
//   {
//     id: 8,
//     image:
//       "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1",
//     title: "Nutriboot Okra Chips – Spice & Stormy",
//     category: "SWEETS & SAVOURIES",
//     rating: 4.8,
//     reviews: 286,
//     price: "₹1,179",
//     oldPrice: "₹1,749",
//     sale: true,
//   },
// ];

// const AllProduct = () => {
//   const navigate = useNavigate();

//   const handleQuickView = (id) => {
//     navigate(`/product/${id}`);
//   };

//   return (
//     <div className="container mx-auto px-4 py-8">
//       {/* Header */}
//       <h2 className="text-2xl font-bold text-gray-800 mb-6">Best Selling</h2>

//       {/* Grid Layout */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
//         {products.map((product) => (
//           <div
//             key={product.id}
//             className="border rounded-lg p-4 hover:shadow-lg relative"
//           >
//             {/* Sale Badge */}
//             {product.sale && (
//               <span className="absolute top-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
//                 Sale!
//               </span>
//             )}

//             {/* Product Image */}
//             <img
//               src={product.image}
//               alt={product.title}
//               className="w-full h-40 object-contain mb-4"
//             />

//             {/* Product Details */}
//             <h3 className="text-sm font-semibold text-gray-800">
//               {product.title}
//             </h3>
//             <div className="flex items-center my-2">
//               <span className="text-yellow-500 text-sm font-medium mr-2">
//                 ★ {product.rating}
//               </span>
//               <span className="text-gray-500 text-sm">
//                 ({product.reviews} Reviews)
//               </span>
//             </div>
//             <p className="text-sm text-gray-500">
//               From:{" "}
//               <span className="line-through text-gray-400">
//                 {product.oldPrice}
//               </span>{" "}
//               <span className="text-gray-800">{product.price}</span>
//             </p>
//             <p className="text-xs text-gray-600 mt-2">{product.category}</p>

//             {/* Quick View Button */}
//             <button
//               className="mt-4 w-full py-2 text-sm text-green-500 border border-[#5eb7b2] rounded-lg hover:bg-[#5eb7b2] hover:text-white transition"
//               onClick={() => handleQuickView(product.id)}
//             >
//               Quick view
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default AllProduct;

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AllProduct = () => {
  const [products, setProducts] = useState([]); // State to store products
  const [loading, setLoading] = useState(true); // State for loading indicator
  const [error, setError] = useState(null); // State for error handling
  const navigate = useNavigate();

  // Fetch products data from API
  const API = "https://fakestoreapi.com/products/";
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get(API);
        // console.log(response);
        setProducts(response.data); // Set products state with API response data
        setLoading(false); // Set loading to false after data is fetched
      } catch (err) {
        setError("Failed to load products"); // Error handling
        setLoading(false); // Set loading to false after error
      }
    };

    fetchProducts();
  }, []); // Empty dependency array to run the effect only once

  const handleQuickView = (id) => {
    navigate(`/product/${id}`);
  };

  if (loading) {
    return <div>Loading...</div>; // Show loading text when fetching data
  }

  if (error) {
    return <div>{error}</div>; // Show error message if there's an error
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <h2 className="text-2xl font-bold text-gray-800 mb-6">All Products</h2>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div
            key={product.id}
            className="border rounded-lg p-4 hover:shadow-lg relative"
          >
            {/* Product Image */}
            <img
              src={product.image}
              alt={product.title}
              className="w-full h-40 object-contain mb-4"
            />

            {/* Product Details */}
            <h3 className="text-sm font-semibold text-gray-800">
              {product.title}
            </h3>
            <div className="flex items-center my-2">
              {/* Ensure we are correctly accessing the 'rate' and 'count' from rating */}
              <span className="text-yellow-500 text-sm font-medium mr-2">
                ★ {product.rating.rate}{" "}
                {/* Access 'rate' from the rating object */}
              </span>
              <span className="text-gray-500 text-sm">
                ({product.rating.count} Reviews){" "}
                {/* Access 'count' from the rating object */}
              </span>
            </div>
            <p className="text-sm text-gray-500">
              From:{" "}
              <span className="line-through text-gray-400">
                {product.oldPrice}
              </span>{" "}
              <span className="text-gray-800">{product.price}</span>
            </p>
            <p className="text-xs text-gray-600 mt-2">{product.category}</p>

            {/* Quick View Button */}
            <button
              className="mt-4 w-full py-2 text-sm text-green-500 border border-[#5eb7b2] rounded-lg hover:bg-[#5eb7b2] hover:text-white transition"
              onClick={() => handleQuickView(product.id)}
            >
              Quick view
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AllProduct;
