// import React from "react";
// import { useParams } from "react-router-dom";

// const img =
//   "https://b2861582.smushcdn.com/2861582/wp-content/uploads/2023/02/splash-01-605-v1.png?lossy=2&strip=1&webp=1";
// const products = [
//   {
//     id: 1,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 2,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 3,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 4,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 5,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 6,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 7,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   {
//     id: 8,
//     image: img,
//     title: "Phalada Pure & Sure | Organic Clean Matcha Green Tea-20Bag/Pkt",
//     category: "Hot-Beverages",
//     rating: 4.7,
//     feedbackCount: 21671,
//     price: "₹75.0",
//     availability: "In Stock",
//     description: "20Bag/Pkt",
//     thumbnails: [img, img, img, img],
//   },
//   // Add other products if needed
// ];

// const SingleProductView = () => {
//   const { id } = useParams();
//   const product = products.find((product) => product.id === parseInt(id));

//   if (!product) {
//     return <div>Product not found!</div>;
//   }

//   return (
//     <div className="container mx-auto px-4 py-8 m-8">
//       <div className="flex flex-col lg:flex-row gap-6">
//         {/* Left Section - Product Images */}
//         <div className="flex-1">
//           <div className="border rounded-lg p-4">
//             <img
//               src={product.image}
//               alt={product.title}
//               className="w-[10rem] h-[15rem] object-contain"
//             />
//           </div>
//           {/* Thumbnails */}
//           <div className="flex gap-2 mt-4">
//             {product.thumbnails.map((thumb, index) => (
//               <div
//                 key={index}
//                 className="border rounded-lg p-1 cursor-pointer hover:shadow-md"
//               >
//                 <img
//                   src={thumb}
//                   alt={`Thumbnail ${index + 1}`}
//                   className="w-16 h-16 object-contain"
//                 />
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Right Section - Product Details */}
//         <div className="flex-1">
//           {/* Rating and Title */}
//           <div className="mb-4">
//             <div className="flex items-center">
//               <span className="text-yellow-500 text-lg font-bold">
//                 ★ {product.rating}
//               </span>
//               <span className="ml-2 text-gray-500 text-sm">
//                 ({product.feedbackCount} User feedback)
//               </span>
//             </div>
//             <h1 className="text-2xl font-bold text-gray-800 mt-2">
//               {product.title}
//             </h1>
//           </div>

//           {/* Availability, Category, and Price */}
//           <div className="mb-4">
//             <p className="text-green-600 font-semibold">
//               {product.availability}
//             </p>
//             <p className="text-gray-600">
//               Category:{" "}
//               <span className="text-blue-600 underline">
//                 {product.category}
//               </span>
//             </p>
//             <p className="text-2xl font-bold text-gray-800 mt-2">
//               {product.price}
//             </p>
//             <p className="text-gray-600">{product.description}</p>
//           </div>

//           {/* Pincode Check */}
//           <div className="flex items-center gap-2 mb-4">
//             <input
//               type="text"
//               placeholder="ENTER PINCODE"
//               className="border rounded-lg px-4 py-2 flex-1"
//             />
//             <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">
//               CHECK
//             </button>
//           </div>

//           {/* Action Buttons */}
//           <div className="flex gap-4">
//             <button className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
//               ADD TO CART
//             </button>
//             <button className="flex-1 border border-green-600 text-green-600 px-4 py-2 rounded-lg hover:bg-green-600 hover:text-white">
//               Buy Now
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SingleProductView;

import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const SingleProductView = () => {
  const { id } = useParams(); // Get the product ID from the URL
  const [product, setProduct] = useState(null); // State to store the product details
  const [loading, setLoading] = useState(true); // State for loading indicator
  const [error, setError] = useState(null); // State for error handling

  const API = `https://fakestoreapi.com/products/${id}`;
  useEffect(() => {
    // Fetch the product data from the API
    const fetchProduct = async () => {
      try {
        const response = await axios.get(API);
        setProduct(response.data); // Set the product details
        setLoading(false); // Set loading to false after data is fetched
      } catch (err) {
        setError("Failed to load product details"); // Handle errors
        setLoading(false); // Set loading to false after error
      }
    };

    fetchProduct(); // Call the function to fetch product details
  }, [id]); // Run the effect again if the product ID changes

  if (loading) {
    return <div>Loading...</div>; // Show loading text while fetching data
  }

  if (error) {
    return <div>{error}</div>; // Show error message if there's an error
  }

  if (!product) {
    return <div>Product not found!</div>; // Show message if product is not found
  }

  return (
    <div className="container mx-auto px-4 py-8 m-8">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Left Section - Product Images */}
        <div className="flex-1">
          <div className="border rounded-lg p-4">
            <img
              src={product.image}
              alt={product.title}
              className="w-[10rem] h-[15rem] object-contain"
            />
          </div>
          {/* Thumbnails */}
          <div className="flex gap-2 mt-4">
            {product.images?.map((thumb, index) => (
              <div
                key={index}
                className="border rounded-lg p-1 cursor-pointer hover:shadow-md"
              >
                <img
                  src={thumb}
                  alt={`Thumbnail ${index + 1}`}
                  className="w-16 h-16 object-contain"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Right Section - Product Details */}
        <div className="flex-1">
          {/* Rating and Title */}
          <div className="mb-4">
            <div className="flex items-center">
              <span className="text-yellow-500 text-lg font-bold">
                ★ {product.rating?.rate || "N/A"} {/* Rating */}
              </span>
              <span className="ml-2 text-gray-500 text-sm">
                ({product.rating?.count || 0} User feedback)
              </span>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mt-2">
              {product.title}
            </h1>
          </div>

          {/* Availability, Category, and Price */}
          <div className="mb-4">
            <p className="text-green-600 font-semibold">
              {product.availability || "In Stock"}
            </p>
            <p className="text-gray-600">
              Category:{" "}
              <span className="text-blue-600 underline">
                {product.category}
              </span>
            </p>
            <p className="text-2xl font-bold text-gray-800 mt-2">
              {product.price}
            </p>
            <p className="text-gray-600">{product.description}</p>
          </div>

          {/* Pincode Check */}
          <div className="flex items-center gap-2 mb-4">
            <input
              type="text"
              placeholder="ENTER PINCODE"
              className="border rounded-lg px-4 py-2 flex-1"
            />
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">
              CHECK
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
              ADD TO CART
            </button>
            <button className="flex-1 border border-green-600 text-green-600 px-4 py-2 rounded-lg hover:bg-green-600 hover:text-white">
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SingleProductView;
