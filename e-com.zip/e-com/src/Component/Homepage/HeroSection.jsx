import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";

const HeroSection = () => {
  return (
    <>
      <Carousel
        autoPlay
        interval={1000}
        showThumbs={false}
        showArrows={true}
        infiniteLoop={true}
      >
         <div>
          <img
            className="h-[50rem]"
            src="https://static.vecteezy.com/system/resources/previews/003/240/364/non_2x/shopping-online-on-phone-paper-art-modern-pink-background-gifts-box-free-vector.jpg"
          />
        </div>
        <div>
          <img
            className="h-[50rem]"
            src="https://static.vecteezy.com/system/resources/thumbnails/004/707/502/small_2x/online-shopping-on-phone-buy-sell-business-digital-web-banner-application-money-advertising-payment-ecommerce-illustration-search-vector.jpg"
          />
        </div>
        <div>
        <img
            className="h-[50rem]"
            src="https://static.vecteezy.com/system/resources/previews/006/633/040/non_2x/online-shopping-spring-on-phone-flower-pink-big-sale-banner-marketing-poster-fashion-vector.jpg"
          />
        </div>
        <div>
          <img
            className="h-[50rem]"
            src="https://t3.ftcdn.net/jpg/02/62/18/46/360_F_262184611_bXhmboL9oE6k2ILu4qXxNWFhNJCEbTn2.jpg"
          />
        </div>
      </Carousel>
    </>
  );
};

export default HeroSection;
