import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FiSearch } from "react-icons/fi";
import { FaUser } from "react-icons/fa";
import { TiThMenu } from "react-icons/ti";
import { ImCross } from "react-icons/im";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-gray-100 w-full sticky top-0 z-50 h-[5rem]">
      <div className="mx-auto flex flex-col items-center px-4 ">
        {/* Mobile Layout: First Line - Logo and Menu Button */}
        <div className="flex items-center justify-between w-full">
          {/* Left Side - Logo (Visible on mobile, hidden on laptop and above) */}
          <div className="text-white font-bold text-2xl flex items-center lg:hidden">
            <Link to="/">
              <img
                src="https://cornerofwakeforest.com/wp-content/uploads/2023/05/dummy-logo-5b.png"
                alt="Logo"
                className="w-[10rem] h-[5rem]"
              />
            </Link>
          </div>

          {/* Mobile Menu Button with Transition */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="text-black text-2xl p-2 transition-all duration-300 ease-in-out transform hover:scale-110 focus:outline-none"
            >
              <TiThMenu />
            </button>
          </div>
        </div>

        {/* Desktop and Tablet Layout (md and above): Everything in one line */}
        <div className="hidden lg:flex items-center justify-between w-full px-4 ">
          {/* Left Side - Logo (Hidden on mobile and tablet, visible only on larger screens) */}
          <div className="text-white font-bold text-2xl flex items-center lg:block">
            <Link to="/">
              <img
                src="https://cornerofwakeforest.com/wp-content/uploads/2023/05/dummy-logo-5b.png"
                alt="Logo"
                className="w-[10rem] h-[5rem]"
              />
            </Link>
          </div>

          {/* Middle - Search Bar */}
          <div className="flex items-center w-1/3">
            <input
              type="text"
              className="w-full p-2 rounded-l-lg border border-gray-700 focus:outline-none text-black bg-white"
              placeholder="Search for products"
            />
            <button className="p-2 bg-white text-black rounded-r-lg h-[2.5rem]">
              <FiSearch className="h-5 w-5" />
            </button>
          </div>

          {/* Right Side - Navigation Items and User Icon */}
          <div className="flex items-center space-x-4 mr-[3rem]">
            <Link to="/" className="text-black font-bold text-[18px]">
              Home
            </Link>
            <Link to="/product" className="text-black font-bold text-[18px]">
              Product
            </Link>
            <Link to="/contact" className="text-black font-bold text-[18px]">
              Contact
            </Link>

            {/* User Icon with green background */}
            <div className="flex items-center justify-center bg-gray-500 rounded-full px-2 gap-2">
              <Link
                to="/login"
                className="flex p-2 gap-2 items-center justify-center"
              >
                <FaUser className="text-white" />
                <p className="text-white">Login</p>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMenuOpen && (
        <div className="md:hidden bg-gray-100 p-4 absolute top-0 right-0 w-full h-[60rem] z-40">
          <button
            onClick={toggleMenu}
            className="text-black text-3xl absolute top-4 right-4"
          >
            <ImCross className="text-[1rem]" />
          </button>
          <div className="flex flex-col space-y-4 text-white text-xl">
            <div className="flex items-center w-full mt-10">
              <input
                type="text"
                className="w-full p-1.5 rounded-l-lg border border-gray-700 focus:outline-none text-black bg-white"
                placeholder="Search for products"
              />
              <button className="p-2 bg-white text-black rounded-r-lg h-[2.5rem]">
                <FiSearch className="h-5 w-5" />
              </button>
            </div>
            <Link to="/" onClick={toggleMenu} className="hover:text-green-400 text-black">
              Home
            </Link>
            <Link
              to="/about"
              onClick={toggleMenu}
              className="hover:text-green-400  text-black"
            >
              About Us
            </Link>
            <Link
              to="/contact"
              onClick={toggleMenu}
              className="hover:text-green-400  text-black"
            >
              Contact
            </Link>
          </div>

          <div className="flex items-center justify-center bg-gray-500 rounded-full p-2 gap-2 mt-2">
            <FaUser className="text-white" />
            <p className="text-white">Login</p>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
