import React from "react";
import { FaFacebookSquare } from "react-icons/fa";
import { FaSquareXTwitter } from "react-icons/fa6";
import { FaLinkedin } from "react-icons/fa";
import { IoLogoYoutube } from "react-icons/io";
import { GrInstagram } from "react-icons/gr";

const Footer = () => {
  return (
    <footer className="bg-gray-100 text-black text-4xl font-bold py-10 px-6 md:px-16 lg:px-24">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Left Section - Logo and Contact */}
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <span className="text-black">Logo</span>Ipsum
          </h2>
          <p className="mt-4 text-sm">
            Reg. Office
            <br />
            #26/A, Hanumaiha Layout, Veerasagara Road,
            <br />
            Attur Layout, Yelahanka New Town,
            <br />
            Bangalore, Karnataka - 560064
          </p>
          <p className="mt-2 text-sm">Contact us - Call: +91-7411023781</p>
          <p className="mt-1 text-sm">Whatsapp: +91-9902826711</p>
          <p className="mt-1 text-sm">E-Mail: pointarogya@gmail.com</p>
        </div>

        {/* Middle Section - Categories */}
        <div>
          <h3 className="text-lg font-semibold">USEFUL LINK</h3>
          <ul className="mt-4 space-y-2 text-sm">
            <li>Home</li>
            <li>Product</li>
            <li> Contact</li>
            <li> Profile</li>
          </ul>
        </div>

        {/* Right Section - Map */}
        <div className="flex justify-center md:justify-end">
          <iframe
            className="w-full h-40 md:h-48 lg:h-56 rounded"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.716163949953!2d77.58489631480667!3d12.92196249087759!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae164b0c5e57fd%3A0x8c3eb6e1e7b8a29e!2sBangalore%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1624360192148!5m2!1sen!2sin"
            allowFullScreen=""
            loading="lazy"
          ></iframe>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="mt-8 border-t border-white/20 pt-6 flex flex-col md:flex-row justify-between items-center text-sm">
        <p>© 2024 Arogyapoint.com Design. All rights reserved.</p>
        <div className="flex space-x-4 mt-4 md:mt-0">
          <a href="#" className="text-black text-xl ">
            <FaFacebookSquare />
          </a>
          <a href="#" className="text-black text-xl ">
            <FaSquareXTwitter />
          </a>
          <a href="#" className="text-black text-xl ">
            <FaLinkedin />
          </a>
          <a href="#" className="text-black text-xl ">
            <IoLogoYoutube />
          </a>
          <a href="#" className="text-black text-xl ">
            <GrInstagram />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
