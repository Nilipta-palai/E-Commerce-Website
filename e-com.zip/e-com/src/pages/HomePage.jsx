import React from "react";
import Navbar from "../Layout/Navbar";
import HeroSection from "../Component/Homepage/HeroSection";
import Footer from "../Layout/Footer";

const HomePage = () => {
  return (
    <>
      <Navbar />
      <HeroSection />
      <Footer />
    </>
  );
};

export default HomePage;
