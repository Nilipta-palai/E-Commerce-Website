import React from "react";
import Navbar from "../Layout/Navbar";
import Footer from "../Layout/Footer";
import SingleProductView from "../Component/Product/SingleProductView";

const ProductDetailPage = () => {
  return (
    <>
      <Navbar />
      <SingleProductView />
      <Footer />
    </>
  );
};

export default ProductDetailPage;
