import React from "react";
import LoginForm from "../Component/Login/LoginForm";
import Navbar from "../Layout/Navbar";
import Footer from "../Layout/Footer";

const LoginPage = () => {
  return (
    <>
      <Navbar />
      <LoginForm />
      <Footer />
    </>
  );
};

export default LoginPage;
