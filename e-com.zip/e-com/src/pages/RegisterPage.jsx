import React from "react";
import RegisterForm from "../Component/Register/RegisterForm";
import Navbar from "../Layout/Navbar";
import Footer from "../Layout/Footer";

const RegisterPage = () => {
  return (
    <>
      <Navbar />
      <RegisterForm />
      <Footer />
    </>
  );
};

export default RegisterPage;
