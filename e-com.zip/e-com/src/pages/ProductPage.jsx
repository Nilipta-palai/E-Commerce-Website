import React from "react";
import Navbar from "../Layout/Navbar";
import Footer from "../Layout/Footer";
import AllProduct from "../Component/Product/AllProduct";

const ProductPage = () => {
  return (
    <>
      <Navbar />
      <AllProduct />
      <Footer />
    </>
  );
};

export default ProductPage;
